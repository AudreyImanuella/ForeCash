-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: forecash
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anggaran`
--

DROP TABLE IF EXISTS `anggaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anggaran` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `batas` decimal(14,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `anggaran_user_id_category_id_unique` (`user_id`,`category_id`),
  KEY `anggaran_category_id_foreign` (`category_id`),
  CONSTRAINT `anggaran_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `anggaran_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anggaran`
--

LOCK TABLES `anggaran` WRITE;
/*!40000 ALTER TABLE `anggaran` DISABLE KEYS */;
INSERT INTO `anggaran` VALUES (1,1,1,600000.00,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,2,200000.00,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,1,5,100000.00,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,1,4,150000.00,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `anggaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis` enum('pemasukan','pengeluaran') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_user_id_foreign` (`user_id`),
  CONSTRAINT `categories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,NULL,'Makan & Minum','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,NULL,'Transportasi','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,NULL,'Kos / Sewa','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,NULL,'Kebutuhan Kuliah','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44'),(5,NULL,'Hiburan','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44'),(6,NULL,'Lainnya','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44'),(7,NULL,'Uang Saku','pemasukan','2026-11-26 06:01:44','2026-11-26 06:01:44'),(8,NULL,'Kerja Sampingan','pemasukan','2026-11-26 06:01:44','2026-11-26 06:01:44'),(9,NULL,'Beasiswa','pemasukan','2026-11-26 06:01:44','2026-11-26 06:01:44'),(10,NULL,'Pelunasan Utang/Piutang','pemasukan','2026-11-26 06:01:44','2026-11-26 06:01:44'),(11,NULL,'Pelunasan Utang/Piutang','pengeluaran','2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `nama_teman` varchar(100) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `arah` enum('piutang','utang') NOT NULL,
  `status` enum('belum','lunas') NOT NULL DEFAULT 'belum',
  `jatuh_tempo` date DEFAULT NULL,
  `teman_id` bigint(20) unsigned DEFAULT NULL,
  `pasangan_id` bigint(20) unsigned DEFAULT NULL,
  `perlu_dicatat` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `debts_teman_id_foreign` (`teman_id`),
  KEY `debts_pasangan_id_foreign` (`pasangan_id`),
  KEY `debts_user_id_status_index` (`user_id`,`status`),
  CONSTRAINT `debts_pasangan_id_foreign` FOREIGN KEY (`pasangan_id`) REFERENCES `debts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `debts_teman_id_foreign` FOREIGN KEY (`teman_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `debts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debts`
--

LOCK TABLES `debts` WRITE;
/*!40000 ALTER TABLE `debts` DISABLE KEYS */;
INSERT INTO `debts` VALUES (1,1,'Andi','Patungan makan',28000.00,'piutang','belum','2026-11-29',NULL,NULL,0,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,'Sasa','Pinjam ongkos',20000.00,'utang','belum',NULL,NULL,NULL,0,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,1,'Andi Pratama','Split bill: pizza malam',35000.00,'piutang','belum','2026-11-30',2,4,0,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,2,'Momo Mahasiswa','Split bill: pizza malam',35000.00,'utang','belum','2026-11-30',1,3,0,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `debts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_schedules`
--

DROP TABLE IF EXISTS `income_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `sumber` varchar(100) NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `tanggal_perkiraan` date NOT NULL,
  `status` enum('menunggu','diterima') NOT NULL DEFAULT 'menunggu',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `income_schedules_user_id_foreign` (`user_id`),
  CONSTRAINT `income_schedules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_schedules`
--

LOCK TABLES `income_schedules` WRITE;
/*!40000 ALTER TABLE `income_schedules` DISABLE KEYS */;
INSERT INTO `income_schedules` VALUES (1,1,'Uang saku dari orang tua',1000000.00,'2026-12-09','menunggu','2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `income_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_11_24_193148_add_forecash_columns_to_users_table',1),(5,'2026_11_24_193250_create_wallets_table',1),(6,'2026_11_24_193313_create_categories_table',1),(7,'2026_11_24_193338_create_transactions_table',1),(8,'2026_11_24_200001_create_income_schedules_table',1),(9,'2026_11_24_200002_create_debts_table',1),(10,'2026_11_24_200003_create_parent_links_table',1),(11,'2026_11_24_200004_create_teman_table',1),(12,'2026_11_24_200005_create_anggaran_table',1),(13,'2026_11_24_200006_create_target_tabungan_table',1),(14,'2026_11_24_200007_create_rencana_pengeluaran_table',1),(15,'2026_11_24_200008_create_user_pets_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parent_links`
--

DROP TABLE IF EXISTS `parent_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orangtua_id` bigint(20) unsigned NOT NULL,
  `anak_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parent_links_orangtua_id_anak_id_unique` (`orangtua_id`,`anak_id`),
  KEY `parent_links_anak_id_foreign` (`anak_id`),
  CONSTRAINT `parent_links_anak_id_foreign` FOREIGN KEY (`anak_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `parent_links_orangtua_id_foreign` FOREIGN KEY (`orangtua_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parent_links`
--

LOCK TABLES `parent_links` WRITE;
/*!40000 ALTER TABLE `parent_links` DISABLE KEYS */;
INSERT INTO `parent_links` VALUES (1,3,1,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `parent_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rencana_pengeluaran`
--

DROP TABLE IF EXISTS `rencana_pengeluaran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rencana_pengeluaran` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `tanggal` date NOT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `berulang` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('rencana','selesai') NOT NULL DEFAULT 'rencana',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rencana_pengeluaran_category_id_foreign` (`category_id`),
  KEY `rencana_pengeluaran_user_id_status_tanggal_index` (`user_id`,`status`,`tanggal`),
  CONSTRAINT `rencana_pengeluaran_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `rencana_pengeluaran_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rencana_pengeluaran`
--

LOCK TABLES `rencana_pengeluaran` WRITE;
/*!40000 ALTER TABLE `rencana_pengeluaran` DISABLE KEYS */;
INSERT INTO `rencana_pengeluaran` VALUES (1,1,'Patungan kado ultah Sasa',50000.00,'2026-12-01',NULL,0,'rencana','2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,'Bayar kos',1200000.00,'2026-12-13',3,1,'rencana','2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,1,'Cicilan UKT',500000.00,'2026-12-21',4,0,'rencana','2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `rencana_pengeluaran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setoran_tabungan`
--

DROP TABLE IF EXISTS `setoran_tabungan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setoran_tabungan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `target_id` bigint(20) unsigned NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `tanggal` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `setoran_tabungan_target_id_foreign` (`target_id`),
  KEY `setoran_tabungan_user_id_tanggal_index` (`user_id`,`tanggal`),
  CONSTRAINT `setoran_tabungan_target_id_foreign` FOREIGN KEY (`target_id`) REFERENCES `target_tabungan` (`id`) ON DELETE CASCADE,
  CONSTRAINT `setoran_tabungan_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setoran_tabungan`
--

LOCK TABLES `setoran_tabungan` WRITE;
/*!40000 ALTER TABLE `setoran_tabungan` DISABLE KEYS */;
INSERT INTO `setoran_tabungan` VALUES (1,1,1,1000000.00,'2026-11-06','2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,1,500000.00,'2026-11-20','2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,1,2,300000.00,'2026-11-13','2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,1,2,150000.00,'2026-11-24','2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `setoran_tabungan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_tabungan`
--

DROP TABLE IF EXISTS `target_tabungan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `target_tabungan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `nama` varchar(80) NOT NULL,
  `target` decimal(14,2) NOT NULL,
  `terkumpul` decimal(14,2) NOT NULL DEFAULT 0.00,
  `tenggat` date DEFAULT NULL,
  `tercapai_pada` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `target_tabungan_user_id_foreign` (`user_id`),
  CONSTRAINT `target_tabungan_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_tabungan`
--

LOCK TABLES `target_tabungan` WRITE;
/*!40000 ALTER TABLE `target_tabungan` DISABLE KEYS */;
INSERT INTO `target_tabungan` VALUES (1,1,'Laptop baru',8000000.00,1500000.00,'2027-06-14',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,'Tiket konser',750000.00,450000.00,'2027-01-10',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `target_tabungan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teman`
--

DROP TABLE IF EXISTS `teman`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teman` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `teman_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teman_user_id_teman_id_unique` (`user_id`,`teman_id`),
  KEY `teman_teman_id_foreign` (`teman_id`),
  CONSTRAINT `teman_teman_id_foreign` FOREIGN KEY (`teman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teman_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teman`
--

LOCK TABLES `teman` WRITE;
/*!40000 ALTER TABLE `teman` DISABLE KEYS */;
INSERT INTO `teman` VALUES (1,1,2,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,2,1,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `teman` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `wallet_id` bigint(20) unsigned NOT NULL,
  `wallet_tujuan_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `jenis` enum('pemasukan','pengeluaran','transfer') NOT NULL,
  `nominal` decimal(14,2) NOT NULL,
  `keterangan` varchar(150) NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_wallet_id_foreign` (`wallet_id`),
  KEY `transactions_wallet_tujuan_id_foreign` (`wallet_tujuan_id`),
  KEY `transactions_category_id_foreign` (`category_id`),
  KEY `transactions_user_id_tanggal_index` (`user_id`,`tanggal`),
  CONSTRAINT `transactions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`),
  CONSTRAINT `transactions_wallet_tujuan_id_foreign` FOREIGN KEY (`wallet_tujuan_id`) REFERENCES `wallets` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,2,NULL,7,'pemasukan',1000000.00,'Uang saku bulanan','2026-11-13',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,2,3,NULL,'transfer',300000.00,'Isi GoPay','2026-11-14',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,1,3,NULL,1,'pengeluaran',85000.00,'Makan bareng teman','2026-11-14',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,1,2,NULL,3,'pengeluaran',250000.00,'Bayar kos (cicilan)','2026-11-13',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(5,1,3,NULL,2,'pengeluaran',40000.00,'Ojek online','2026-11-17',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(6,1,1,NULL,1,'pengeluaran',60000.00,'Makan kantin','2026-11-18',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(7,1,3,NULL,5,'pengeluaran',75000.00,'Nonton bioskop','2026-11-20',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(8,1,1,NULL,4,'pengeluaran',35000.00,'Print tugas','2026-11-21',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(9,1,3,NULL,1,'pengeluaran',55000.00,'Kopi & camilan','2026-11-23',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(10,1,1,NULL,2,'pengeluaran',30000.00,'Bensin','2026-11-24',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(11,1,1,NULL,1,'pengeluaran',45000.00,'Makan siang','2026-11-25',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_pets`
--

DROP TABLE IF EXISTS `user_pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_pets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `pet_id` varchar(30) NOT NULL,
  `menetas_pada` date NOT NULL,
  `dipakai` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_pets_user_id_pet_id_unique` (`user_id`,`pet_id`),
  CONSTRAINT `user_pets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_pets`
--

LOCK TABLES `user_pets` WRITE;
/*!40000 ALTER TABLE `user_pets` DISABLE KEYS */;
INSERT INTO `user_pets` VALUES (1,1,'celeng','2026-11-16',1,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,'mochi','2026-11-21',0,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `user_pets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'mahasiswa',
  `avatar` varchar(10) NOT NULL DEFAULT 'a1',
  `batas_harian` decimal(14,2) NOT NULL DEFAULT 0.00,
  `kode_hubung` varchar(8) DEFAULT NULL,
  `kode_teman` varchar(6) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_kode_hubung_unique` (`kode_hubung`),
  UNIQUE KEY `users_kode_teman_unique` (`kode_teman`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Momo Mahasiswa','demo@forecash.id','mahasiswa','a2',45000.00,'DEMO2026','MOMO26','2026-11-26 06:01:44','$2y$12$.LTIsrwfzOfLE3dO9HaI0efNdHmrv.pKDPjcNbyiWYW0ST7MSi2SS',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,'Andi Pratama','teman@forecash.id','mahasiswa','a3',0.00,NULL,'ANDI26','2026-11-26 06:01:44','$2y$12$ktM6tX/b462pMbfedkzeke4u5rn9f6db0mlWbLtxF5O54Wn/oxobi',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,'Ibu Momo','ortu@forecash.id','orangtua','a4',0.00,NULL,NULL,'2026-11-26 06:01:44','$2y$12$3tHm.StGnjnZ0Z2qzBWPGuSA0vp.cM44uIkgEEdmWDZIx.Chd36La',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,'Admin ForeCash','admin@forecash.id','admin','a1',0.00,NULL,NULL,'2026-11-26 06:01:45','$2y$12$RiJXhhnzJrdgtlz98buELeW8zXdJF9HMSgmLHkshYcVVEAiJ1jw0y',NULL,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wallets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tipe` enum('tunai','bank','ewallet') NOT NULL DEFAULT 'tunai',
  `saldo_awal` decimal(14,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_foreign` (`user_id`),
  CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES (1,1,'Utama','tunai',250000.00,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(2,1,'BCA','bank',0.00,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(3,1,'GoPay','ewallet',0.00,'2026-11-26 06:01:44','2026-11-26 06:01:44'),(4,2,'Utama','tunai',300000.00,'2026-11-26 06:01:44','2026-11-26 06:01:44');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-26 20:07:09
