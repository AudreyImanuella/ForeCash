

<?php use \App\Support\Format; ?>

<?php $__env->startSection('judul', 'Rencana'); ?>
<?php $__env->startSection('judul_halaman', 'Rencana'); ?>

<?php
    $WARNA = ['aman' => 'bg-hsGreen', 'hampir' => 'bg-hsYellow', 'lewat' => 'bg-hsRed'];
    $KET = ['aman' => 'text-slate-500', 'hampir' => 'text-amber-700', 'lewat' => 'text-hsRed'];
    $BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $errorBag = collect(['rencana', 'target'])->map(fn ($b) => $errors->$b->first())->filter()->first();
?>

<?php $__env->startSection('isi'); ?>
    <div><p class="text-xs text-slate-500">Atur anggaran, tabungan, dan pengeluaran besar sebelum terjadi. Rencana pengeluaran otomatis ikut dihitung di Prediksi.</p></div>

    <?php if($errorBag): ?>
        <p class="fc-flash is-error" role="alert"><?php echo e($errorBag); ?></p>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <div class="lg:col-span-2 space-y-6">
            
            <section class="hs-card p-6 space-y-2" aria-label="Anggaran per kategori">
                <div class="flex justify-between items-baseline gap-2 flex-wrap">
                    <h4 class="text-sm font-black">Anggaran <?php echo e($namaBulan); ?></h4>
                    <?php if(count($baris)): ?>
                        <span class="text-xs text-slate-500"><?php echo e(Format::rupiah($total['terpakai'])); ?> dari <?php echo e(Format::rupiah($total['batas'])); ?></span>
                    <?php endif; ?>
                </div>
                <?php if(! count($baris)): ?>
                    <?php if (isset($component)) { $__componentOriginal2774db502eccf9ab4eb7044e67aef150 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2774db502eccf9ab4eb7044e67aef150 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kosong','data' => ['judul' => 'Belum ada anggaran']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kosong'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['judul' => 'Belum ada anggaran']); ?>Tentukan batas belanja per kategori supaya tahu kapan harus mengerem. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2774db502eccf9ab4eb7044e67aef150)): ?>
<?php $attributes = $__attributesOriginal2774db502eccf9ab4eb7044e67aef150; ?>
<?php unset($__attributesOriginal2774db502eccf9ab4eb7044e67aef150); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2774db502eccf9ab4eb7044e67aef150)): ?>
<?php $component = $__componentOriginal2774db502eccf9ab4eb7044e67aef150; ?>
<?php unset($__componentOriginal2774db502eccf9ab4eb7044e67aef150); ?>
<?php endif; ?>
                <?php endif; ?>
                <?php $__currentLoopData = $baris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $ket = $a['status'] === 'lewat' ? 'Lewat ' . Format::rupiah(-$a['sisa'])
                            : ($a['status'] === 'hampir' ? 'Hampir habis · sisa ' . Format::rupiah($a['sisa']) : 'Sisa ' . Format::rupiah($a['sisa']));
                    ?>
                    <div class="py-3 border-b last:border-0 space-y-1.5">
                        <div class="flex items-center justify-between gap-2 flex-wrap">
                            <p class="text-sm font-bold"><?php echo e($a['nama']); ?></p>
                            <div class="flex items-center gap-2">
                                <span class="text-xs text-slate-500"><?php echo e(Format::rupiah($a['terpakai'])); ?> / <?php echo e(Format::rupiah($a['batas'])); ?></span>
                                <button type="button" data-buka="#ang<?php echo e($a['category_id']); ?>" class="w-8 h-8 rounded-full bg-amber-50 text-hsOrange inline-flex items-center justify-center"
                                        aria-label="Ubah anggaran <?php echo e($a['nama']); ?>" title="Ubah"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'pencil','size' => 14]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'pencil','size' => 14]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></button>
                            </div>
                        </div>
                        <div class="w-full bg-slate-100 rounded-full h-2.5" role="progressbar" aria-valuenow="<?php echo e($a['persen']); ?>" aria-valuemin="0" aria-valuemax="100" aria-label="Anggaran <?php echo e($a['nama']); ?> terpakai">
                            <div class="<?php echo e($WARNA[$a['status']]); ?> h-2.5 rounded-full" style="width: <?php echo e($a['persen']); ?>%"></div>
                        </div>
                        <p class="text-[11px] font-bold <?php echo e($KET[$a['status']]); ?>"><?php echo e($ket); ?></p>
                        <div id="ang<?php echo e($a['category_id']); ?>" hidden>
                            <form method="POST" action="<?php echo e(route('rencana.anggaran')); ?>" class="flex gap-2 items-center pt-1">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="category_id" value="<?php echo e($a['category_id']); ?>">
                                <input name="batas" type="text" inputmode="numeric" autocomplete="off" value="<?php echo e(Format::isianNominal($a['batas'])); ?>"
                                       aria-label="Batas baru <?php echo e($a['nama']); ?>" class="flex-1 px-3 py-2 text-xs border" data-rupiah>
                                <button type="submit" class="hs-btn bg-slate-800 text-white px-3 py-2 text-xs">Simpan</button>
                            </form>
                            <p class="text-[10px] text-slate-500">Isi 0 untuk menghapus anggaran kategori ini.</p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($kategoriKosong->isNotEmpty()): ?>
                    <form method="POST" action="<?php echo e(route('rencana.anggaran')); ?>" class="pt-3 space-y-2">
                        <?php echo csrf_field(); ?>
                        <p class="text-xs font-bold">Tambah anggaran</p>
                        <div class="flex gap-2 flex-wrap">
                            <select name="category_id" aria-label="Kategori" class="flex-1 min-w-[140px] px-3 py-2 text-xs border">
                                <?php $__currentLoopData = $kategoriKosong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input name="batas" required type="text" inputmode="numeric" autocomplete="off" placeholder="Contoh: 500.000"
                                   aria-label="Batas per bulan" class="flex-1 min-w-[140px] px-3 py-2 text-xs border" data-rupiah>
                            <button type="submit" class="hs-btn bg-hsOrange text-white px-4 py-2 text-xs">Tambah</button>
                        </div>
                    </form>
                <?php endif; ?>
            </section>

            
            <section class="hs-card p-6 space-y-2" aria-label="Pengeluaran yang direncanakan">
                <h4 class="text-sm font-black">Pengeluaran yang Direncanakan</h4>
                <?php if($rencana->isEmpty()): ?>
                    <p class="text-xs text-slate-500">Bayar kos, UKT, kado teman... catat di sini supaya Prediksi tidak kaget.</p>
                <?php endif; ?>
                <?php $__currentLoopData = $rencana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $telat = $r->tanggal->toDateString() < $hari; ?>
                    <div class="py-3 border-b last:border-0 space-y-2">
                        <div class="flex items-center gap-3">
                            <div class="w-14 h-14 rounded-2xl flex flex-col items-center justify-center shrink-0 <?php echo e($telat ? 'bg-red-100 text-hsRed' : 'bg-amber-100'); ?>">
                                <b class="text-lg leading-none"><?php echo e($r->tanggal->day); ?></b><span class="text-[10px] font-bold"><?php echo e($BULAN[$r->tanggal->month - 1]); ?></span>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-bold truncate"><?php echo e($r->nama); ?></p>
                                <p class="text-[11px] <?php echo e($telat ? 'text-hsRed font-bold' : 'text-slate-500'); ?>">
                                    <?php echo e($telat ? 'Lewat sejak ' . Format::tgl($r->tanggal) : ($r->category?->nama ?? 'Tanpa kategori')); ?>

                                    <?php if($r->berulang): ?><span class="inline-flex items-center gap-0.5 ml-1"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'repeat','size' => 11]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'repeat','size' => 11]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> tiap bulan</span><?php endif; ?>
                                </p>
                            </div>
                            <p class="font-black text-sm shrink-0"><?php echo e(Format::rupiah($r->nominal)); ?></p>
                        </div>
                        <div class="flex items-center gap-2">
                            <form method="POST" action="<?php echo e(route('rencana.bayar', $r)); ?>" class="flex gap-2 flex-1">
                                <?php echo csrf_field(); ?>
                                <select name="wallet_id" aria-label="Bayar dari wallet" title="Bayar dari wallet" class="flex-1 min-w-0 px-2 py-1.5 text-[11px] border">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="hs-btn bg-hsGreen text-white px-3 py-1.5 text-[11px]">Sudah dibayar</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('rencana.hapus', $r)); ?>" data-konfirmasi="Hapus rencana ini?">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="w-8 h-8 rounded-full bg-red-50 text-hsRed flex items-center justify-center" title="Hapus" aria-label="Hapus rencana">
                                    <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'trash','size' => 13]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'trash','size' => 13]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($f['rencanaDulu'] > 0): ?>
                    <p class="text-[11px] font-bold rounded-2xl bg-emerald-50 text-emerald-800 px-3 py-2">
                        <?php echo e(Format::rupiah($f['rencanaDulu'])); ?> jatuh sebelum
                        <?php echo e($f['next'] ? 'pemasukan berikutnya (' . Format::tgl($f['next']['tanggal_perkiraan']) . ')' : '30 hari ke depan'); ?>

                        dan sudah dihitung di Prediksi.
                    </p>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('rencana.store')); ?>" class="pt-3 border-t space-y-2">
                    <?php echo csrf_field(); ?>
                    <p class="text-xs font-bold">Tambah rencana</p>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <div>
                            <label for="rn" class="text-xs font-bold">Nama</label>
                            <input id="rn" name="nama" required maxlength="100" value="<?php echo e(old('nama')); ?>" placeholder="Bayar kos Desember" class="w-full px-3 py-2 text-xs border">
                        </div>
                        <div>
                            <label for="rnom" class="text-xs font-bold">Nominal</label>
                            <input id="rnom" name="nominal" required type="text" inputmode="numeric" autocomplete="off" value="<?php echo e(old('nominal')); ?>"
                                   placeholder="Contoh: 1.200.000" class="w-full px-3 py-2 text-xs border" data-rupiah>
                        </div>
                        <div>
                            <label for="rt" class="text-xs font-bold">Tanggal</label>
                            <input id="rt" type="date" name="tanggal" required value="<?php echo e(old('tanggal')); ?>" class="w-full px-3 py-2 text-xs border">
                        </div>
                        <div>
                            <label for="rk" class="text-xs font-bold">Kategori</label>
                            <select id="rk" name="category_id" class="w-full px-3 py-2 text-xs border">
                                <option value="">Tanpa kategori</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($k->id); ?>" <?php if((string) old('category_id') === (string) $k->id): echo 'selected'; endif; ?>><?php echo e($k->nama); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <label class="flex items-center gap-2 text-xs font-bold"><input type="checkbox" name="berulang" value="1" <?php if(old('berulang')): echo 'checked'; endif; ?>> Berulang tiap bulan</label>
                    <button type="submit" class="hs-btn bg-hsOrange text-white w-full py-2.5 text-xs">Simpan Rencana</button>
                </form>
            </section>
        </div>

        
        <section class="hs-card p-6 space-y-3" aria-label="Target tabungan">
            <h4 class="text-sm font-black">Target Tabungan</h4>
            <?php if($targets->isEmpty()): ?>
                <p class="text-xs text-slate-500">Mau beli apa? Laptop, tiket konser, dana darurat... buat targetnya di bawah.</p>
            <?php endif; ?>
            <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i = $t->info; ?>
                <div class="rounded-3xl bg-amber-50 p-4 space-y-2">
                    <div class="flex justify-between items-start gap-2">
                        <div class="min-w-0">
                            <p class="font-black truncate"><?php echo e($t->nama); ?></p>
                            <p class="text-xs text-slate-500">
                                <?php echo e(Format::rupiah($t->terkumpul)); ?> dari <?php echo e(Format::rupiah($t->target)); ?><?php if($t->tenggat): ?> · tenggat <?php echo e(Format::tgl($t->tenggat)); ?><?php endif; ?>
                            </p>
                        </div>
                        <div class="flex items-center gap-2 shrink-0">
                            <b class="text-sm"><?php echo e($i['persen']); ?>%</b>
                            <form method="POST" action="<?php echo e(route('rencana.target.hapus', $t)); ?>" data-konfirmasi="Hapus target &quot;<?php echo e($t->nama); ?>&quot;?">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="w-8 h-8 rounded-full bg-red-50 text-hsRed flex items-center justify-center" title="Hapus" aria-label="Hapus target <?php echo e($t->nama); ?>">
                                    <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'trash','size' => 13]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'trash','size' => 13]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="w-full bg-white rounded-full h-3" role="progressbar" aria-valuenow="<?php echo e($i['persen']); ?>" aria-valuemin="0" aria-valuemax="100" aria-label="Kemajuan <?php echo e($t->nama); ?>">
                        <div class="<?php echo e($i['tercapai'] ? 'bg-hsGreen' : 'bg-hsOrange'); ?> h-3 rounded-full" style="width: <?php echo e($i['persen']); ?>%"></div>
                    </div>
                    <?php if($i['tercapai']): ?>
                        <p class="text-xs font-bold text-hsGreen">Tercapai!</p>
                    <?php else: ?>
                        <p class="text-[11px] font-bold">
                            <?php if($i['perMinggu']): ?>
                                Sisihkan <?php echo e(Format::rupiah($i['perMinggu'])); ?>/minggu supaya tercapai tepat waktu.
                            <?php elseif($i['telat']): ?>
                                Tenggat lewat, kurang <?php echo e(Format::rupiah($i['kurang'])); ?>.
                            <?php else: ?>
                                Kurang <?php echo e(Format::rupiah($i['kurang'])); ?> lagi.
                            <?php endif; ?>
                        </p>
                        <form method="POST" action="<?php echo e(route('rencana.setor', $t)); ?>" class="flex gap-2">
                            <?php echo csrf_field(); ?>
                            <input name="nominal" required type="text" inputmode="numeric" autocomplete="off" placeholder="Contoh: 50.000"
                                   aria-label="Setoran untuk <?php echo e($t->nama); ?>" class="flex-1 min-w-0 px-3 py-2 text-xs border" data-rupiah>
                            <button type="submit" class="hs-btn bg-hsOrange text-white px-3 py-2 text-xs">Setor</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="text-[10px] text-slate-500">Uang tabungan tetap tersimpan di wallet-mu. Kalau mau dipisah, buat wallet "Tabungan".</p>

            <form method="POST" action="<?php echo e(route('rencana.target')); ?>" class="pt-3 border-t space-y-2">
                <?php echo csrf_field(); ?>
                <p class="text-xs font-bold">Target baru</p>
                <div>
                    <label for="tn" class="text-xs font-bold">Nama</label>
                    <input id="tn" name="nama" required maxlength="80" placeholder="Laptop baru" class="w-full px-3 py-2 text-xs border">
                </div>
                <div>
                    <label for="tt" class="text-xs font-bold">Jumlah target</label>
                    <input id="tt" name="target" required type="text" inputmode="numeric" autocomplete="off" placeholder="Contoh: 8.000.000"
                           class="w-full px-3 py-2 text-xs border" data-rupiah>
                </div>
                <div>
                    <label for="tg" class="text-xs font-bold">Tenggat (opsional)</label>
                    <input id="tg" type="date" name="tenggat" class="w-full px-3 py-2 text-xs border">
                </div>
                <button type="submit" class="hs-btn bg-hsOrange text-white w-full py-2.5 text-xs">Buat Target</button>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\audre\ForeCash\resources\views/rencana/index.blade.php ENDPATH**/ ?>