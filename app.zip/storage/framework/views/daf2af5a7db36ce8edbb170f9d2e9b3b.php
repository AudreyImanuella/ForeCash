
<?php
    $t = $t ?? null;
    $jenis = old('jenis', $t?->jenis ?? $jenisAwal ?? 'pengeluaran');
    $transfer = $jenis === 'transfer';
    // old() berisi teks persis seperti yang diketik ("100.000"); titiknya dirapikan oleh JavaScript (data-rupiah)
    $nominalAwal = old('nominal', $t ? number_format((float) $t->nominal, 0, ',', '.') : '');
    $kategoriPilih = old('category_id', $t?->category_id);
    $walletPilih = old('wallet_id', $t?->wallet_id ?? $wallets->first()?->id);
    $tujuanPilih = old('wallet_tujuan_id', $t?->wallet_tujuan_id ?? $wallets->get(1)?->id);
?>

<form method="POST" action="<?php echo e($aksi); ?>" enctype="multipart/form-data" class="hs-card p-5 space-y-3" data-form-tx>
    <?php echo csrf_field(); ?>
    <?php if($t): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <h4 class="text-sm font-black"><?php echo e($t ? 'Ubah Transaksi' : 'Catat Transaksi'); ?></h4>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
            <label for="jenis" class="text-xs font-bold">Jenis</label>
            <select id="jenis" name="jenis" class="w-full px-3 py-2.5 text-sm border" data-pilih-jenis>
                <option value="pengeluaran" <?php if($jenis === 'pengeluaran'): echo 'selected'; endif; ?>>Pengeluaran</option>
                <option value="pemasukan" <?php if($jenis === 'pemasukan'): echo 'selected'; endif; ?>>Pemasukan</option>
                <option value="transfer" <?php if($jenis === 'transfer'): echo 'selected'; endif; ?>>Transfer antar wallet</option>
            </select>
            <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="nominal" class="text-xs font-bold">Nominal (Rp)</label>
            
            <input id="nominal" name="nominal" type="text" inputmode="numeric" autocomplete="off" required
                   value="<?php echo e($nominalAwal); ?>" placeholder="Contoh: 25.000" class="w-full px-3 py-2.5 text-sm border" data-rupiah>
            <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div>
        <label for="keterangan" class="text-xs font-bold">
            Keterangan <span class="font-normal text-slate-400">(opsional · kosong = pakai nama kategori)</span>
        </label>
        <input id="keterangan" name="keterangan" maxlength="150" value="<?php echo e(old('keterangan', $t?->keterangan)); ?>"
               placeholder="Contoh: Makan siang kantin" class="w-full px-3 py-2.5 text-sm border">
        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        
        <div data-bukan-transfer <?php if($transfer): ?> hidden <?php endif; ?>>
            <label for="category_id" class="text-xs font-bold">Kategori</label>
            <select id="category_id" name="category_id" class="w-full px-3 py-2.5 text-sm border" data-pilih-kategori>
                <?php $__currentLoopData = ['pengeluaran' => 'Pengeluaran', 'pemasukan' => 'Pemasukan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <optgroup label="<?php echo e($label); ?>" data-jenis="<?php echo e($j); ?>">
                        <?php $__currentLoopData = $kategori->where('jenis', $j); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>" <?php if((string) $kategoriPilih === (string) $c->id): echo 'selected'; endif; ?>><?php echo e($c->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="tanggal" class="text-xs font-bold">Tanggal</label>
            <input id="tanggal" type="date" name="tanggal" required max="<?php echo e(\App\Support\Format::hariIni()); ?>"
                   value="<?php echo e(old('tanggal', $t?->tanggal?->toDateString() ?? \App\Support\Format::hariIni())); ?>"
                   class="w-full px-3 py-2.5 text-sm border">
            <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
            <label for="wallet_id" class="text-xs font-bold" data-label-wallet><?php echo e($transfer ? 'Dari wallet' : 'Wallet'); ?></label>
            <select id="wallet_id" name="wallet_id" class="w-full px-3 py-2.5 text-sm border">
                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($w->id); ?>" <?php if((string) $walletPilih === (string) $w->id): echo 'selected'; endif; ?>>
                        <?php echo e($w->nama); ?> (<?php echo e(\App\Support\Format::rupiah($w->saldo_sekarang)); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['wallet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div data-hanya-transfer <?php if(! $transfer): ?> hidden <?php endif; ?>>
            <label for="wallet_tujuan_id" class="text-xs font-bold">Ke wallet</label>
            <select id="wallet_tujuan_id" name="wallet_tujuan_id" class="w-full px-3 py-2.5 text-sm border">
                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($w->id); ?>" <?php if((string) $tujuanPilih === (string) $w->id): echo 'selected'; endif; ?>><?php echo e($w->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-[10px] text-slate-500 mt-1">Transfer tidak dihitung sebagai pemasukan/pengeluaran.</p>
            <?php $__errorArgs = ['wallet_tujuan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div>
        <label for="bukti" class="text-xs font-bold">
            Foto struk <span class="font-normal text-slate-400">(opsional · JPG/JPEG/PNG, maks. 2 MB)</span>
        </label>
        <input id="bukti" type="file" name="bukti" accept=".jpg,.jpeg,.png,image/jpeg,image/png"
               class="w-full px-3 py-2 text-xs border bg-white">
        <?php $__errorArgs = ['bukti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-xs font-bold text-hsRed mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if($t?->bukti): ?>
            <div class="flex items-center gap-3 mt-2">
                <a href="<?php echo e(route('transaksi.struk', $t)); ?>" target="_blank" rel="noopener">
                    <img src="<?php echo e(route('transaksi.struk', $t)); ?>" alt="Struk tersimpan" class="w-16 h-16 object-cover rounded-xl border">
                </a>
                <label class="flex items-center gap-2 text-xs font-bold text-hsRed">
                    <input type="checkbox" name="hapus_bukti" value="1" <?php if(old('hapus_bukti')): echo 'checked'; endif; ?>> Hapus foto ini
                </label>
            </div>
        <?php endif; ?>
    </div>

    <?php if($t): ?>
        <div class="flex gap-2">
            <a href="<?php echo e(route('transaksi.index', ['bulan' => $t->tanggal->format('Y-m')])); ?>" class="hs-btn bg-slate-200 px-4 py-3 text-sm">Batal</a>
            <button type="submit" class="hs-btn bg-hsBlue text-white flex-1 py-3 text-sm">Simpan Perubahan</button>
        </div>
    <?php else: ?>
        <button type="submit" class="hs-btn bg-hsOrange text-white w-full py-3 text-sm">Simpan Transaksi</button>
    <?php endif; ?>
</form><?php /**PATH C:\Users\audre\ForeCash\resources\views/transaksi/_form.blade.php ENDPATH**/ ?>