
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['bagian', 'g' => null, 't' => null, 'b' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['bagian', 'g' => null, 't' => null, 'b' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php use \App\Support\Format; ?>
<?php use \App\Support\Gamify; ?>

<?php if($bagian === 'level'): ?>
    <?php
        $pct = $g['nextPoin'] ? (int) round(($g['poin'] - $g['prevPoin']) / ($g['nextPoin'] - $g['prevPoin']) * 100) : 100;
        $ket = $g['nextPoin'] ? ($g['nextPoin'] - $g['poin']) . ' poin lagi menuju ' . $g['nextNama'] : 'Level tertinggi tercapai!';
    ?>
    <div class="flex justify-between text-xs font-bold">
        <span>Level <?php echo e($g['level']); ?> · <?php echo e($g['levelNama']); ?></span>
        <span><?php echo e($g['poin']); ?> poin</span>
    </div>
    <div class="w-full bg-slate-100 rounded-full h-3 mt-1" role="progressbar" aria-valuenow="<?php echo e($pct); ?>" aria-valuemin="0" aria-valuemax="100" aria-label="Kemajuan level">
        <div class="bg-hsPurple h-3 rounded-full" style="width: <?php echo e($pct); ?>%"></div>
    </div>
    <p class="text-[10px] text-slate-500 mt-1"><?php echo e($ket); ?></p>

<?php elseif($bagian === 'tantangan'): ?>
    <?php
        $pct = (int) min(100, round($t['now'] / $t['max'] * 100));
        $angka = fn ($n) => $t['satuan'] === 'rp' ? Format::rupiah($n) : $n . ' hari';
        if ($t['jenis'] === 'maks') {
            $ket = $t['gagal'] ? 'Lewat batas, coba lagi minggu depan' : 'sisa ' . Format::rupiah($t['max'] - $t['now']) . ', ' . $t['sisaHari'] . ' hari lagi';
        } else {
            $ket = $t['selesai'] ? 'Selesai! Mantap.' : ($t['gagal'] ? 'Tidak terkejar minggu ini, coba lagi minggu depan' : ($t['max'] - $t['now']) . ' hari lagi, sisa ' . $t['sisaHari'] . ' hari');
        }
        $warna = $t['selesai'] ? 'bg-hsGreen' : ($t['gagal'] ? 'bg-hsRed' : ($t['jenis'] === 'maks' ? 'bg-hsGreen' : 'bg-hsOrange'));
    ?>
    <p class="text-sm font-bold"><?php echo e($t['judul']); ?></p>
    <div class="w-full bg-slate-100 rounded-full h-3 mt-2" role="progressbar" aria-valuenow="<?php echo e($pct); ?>" aria-valuemin="0" aria-valuemax="100" aria-label="Kemajuan tantangan">
        <div class="<?php echo e($warna); ?> h-3 rounded-full" style="width: <?php echo e($pct); ?>%"></div>
    </div>
    <p class="text-[11px] mt-1 <?php echo e($t['gagal'] ? 'text-hsRed font-bold' : ($t['selesai'] ? 'text-hsGreen font-bold' : 'text-slate-500')); ?>">
        <?php echo e($angka($t['now'])); ?><?php echo e($t['jenis'] === 'maks' ? ' terpakai' : ' dari ' . $angka($t['max'])); ?> · <?php echo e($ket); ?>

    </p>

<?php elseif($bagian === 'badge'): ?>
    <div class="hs-card p-4 text-center space-y-2 <?php echo e($b['tingkat'] === 0 ? 'opacity-75' : ''); ?>">
        <div class="flex justify-center"><?php if (isset($component)) { $__componentOriginal288bd373b2d7d2564afddc7fe7cc4827 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-ikon','data' => ['ikon' => $b['key'],'tingkat' => $b['tingkat'],'size' => 60]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ikon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($b['key']),'tingkat' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($b['tingkat']),'size' => 60]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827)): ?>
<?php $attributes = $__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827; ?>
<?php unset($__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal288bd373b2d7d2564afddc7fe7cc4827)): ?>
<?php $component = $__componentOriginal288bd373b2d7d2564afddc7fe7cc4827; ?>
<?php unset($__componentOriginal288bd373b2d7d2564afddc7fe7cc4827); ?>
<?php endif; ?></div>
        <p class="text-sm font-black"><?php echo e($b['nama']); ?></p>
        <span class="fc-tier fc-tier-<?php echo e($b['tingkat']); ?>"><?php echo e(Gamify::TINGKAT[$b['tingkat']]); ?></span>
        <p class="text-[11px] text-slate-500 min-h-[30px]"><?php echo e($b['ket']); ?></p>
        <?php if($b['berikut'] !== null): ?>
            <div class="w-full bg-slate-100 rounded-full h-2" role="progressbar" aria-valuenow="<?php echo e($b['persen']); ?>" aria-valuemin="0" aria-valuemax="100" aria-label="Kemajuan <?php echo e($b['nama']); ?>">
                <div class="bg-hsOrange h-2 rounded-full" style="width: <?php echo e($b['persen']); ?>%"></div>
            </div>
            <p class="text-[10px] font-bold"><?php echo e(Gamify::sisaBadge($b)); ?> menuju <?php echo e(Gamify::TINGKAT[$b['tingkat'] + 1]); ?></p>
        <?php else: ?>
            <p class="text-[10px] font-bold text-amber-700">Tingkat tertinggi!</p>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\audre\ForeCash\resources\views/components/gamifikasi.blade.php ENDPATH**/ ?>