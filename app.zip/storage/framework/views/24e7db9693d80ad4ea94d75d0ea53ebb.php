
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo trim($__env->yieldContent('judul')) ? trim($__env->yieldContent('judul')) . ' — ' : ''; ?>ForeCash</title>
<meta name="description" content="ForeCash: aplikasi web peringatan dini keuangan untuk mahasiswa.">
<meta name="theme-color" content="#FF8A1F">
<?php echo $__env->yieldPushContent('meta'); ?>

<link rel="preload" href="<?php echo e(asset('fonts/ClashGrotesk-Variable.woff2')); ?>" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="<?php echo e(asset('fonts/SplineSans-Variable.woff2')); ?>" as="font" type="font/woff2" crossorigin>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php /**PATH C:\Users\audre\ForeCash\resources\views/partials/head.blade.php ENDPATH**/ ?>