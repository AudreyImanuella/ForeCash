
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['uid', 'badges']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['uid', 'badges']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php use \App\Support\Gamify; ?>
<div class="fc-badge-toast" role="status" aria-live="polite" hidden
     data-badge-baru="fc_badge_<?php echo e($uid); ?>"
     data-badges='<?php echo json_encode(collect($badges)->mapWithKeys(fn ($b) => [$b['key'] => $b['tingkat']]), 15, 512) ?>'>
    <?php $__currentLoopData = $badges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <template data-badge="<?php echo e($b['key']); ?>">
            <?php if (isset($component)) { $__componentOriginale9273a6e6b83c6abfee85330a8491544 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9273a6e6b83c6abfee85330a8491544 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tupai','data' => ['pose' => 'bangga','class' => 'w-14 h-14 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tupai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pose' => 'bangga','class' => 'w-14 h-14 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $attributes = $__attributesOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__attributesOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $component = $__componentOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__componentOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal288bd373b2d7d2564afddc7fe7cc4827 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-ikon','data' => ['ikon' => $b['key'],'tingkat' => $b['tingkat'],'size' => 44]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ikon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($b['key']),'tingkat' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($b['tingkat']),'size' => 44]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827)): ?>
<?php $attributes = $__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827; ?>
<?php unset($__attributesOriginal288bd373b2d7d2564afddc7fe7cc4827); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal288bd373b2d7d2564afddc7fe7cc4827)): ?>
<?php $component = $__componentOriginal288bd373b2d7d2564afddc7fe7cc4827; ?>
<?php unset($__componentOriginal288bd373b2d7d2564afddc7fe7cc4827); ?>
<?php endif; ?>
            <div class="min-w-0 flex-1">
                <p class="text-[11px] font-black text-hsOrange tracking-wide">BADGE BARU!</p>
                <p class="font-black text-sm"><?php echo e($b['nama']); ?> · <?php echo e(Gamify::TINGKAT[$b['tingkat']]); ?></p>
                <p class="text-[11px] text-slate-500"><span data-lain></span><a href="<?php echo e(route('pencapaian')); ?>" class="font-bold text-hsOrange">Lihat koleksi</a></p>
            </div>
            <button type="button" data-tutup-toast class="w-8 h-8 rounded-full inline-flex items-center justify-center text-slate-500" aria-label="Tutup">
                <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'x','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'x','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
            </button>
        </template>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\audre\ForeCash\resources\views/components/badge-baru.blade.php ENDPATH**/ ?>