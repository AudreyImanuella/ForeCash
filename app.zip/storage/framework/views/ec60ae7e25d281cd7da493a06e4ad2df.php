<?php use \App\Support\Format; ?>

<?php $__env->startSection('judul', 'Dashboard'); ?>
<?php $__env->startSection('judul_halaman', Format::sapaan() . ', ' . $user->namaDepan() . '!'); ?>

<?php
    // tautan ke halaman yang belum ada diarahkan ke '#'
    $ke = fn (string $rute, array $param = []) => Route::has($rute) ? route($rute, $param) : '#';
    $IKON_WALLET = ['tunai' => 'banknote', 'bank' => 'landmark', 'ewallet' => 'smartphone'];
    $KELAS_TX = ['pemasukan' => 'is-in', 'pengeluaran' => 'is-out', 'transfer' => 'is-move'];
    $WARNA_TX = ['pemasukan' => 'fb-in', 'pengeluaran' => 'fb-out', 'transfer' => 'fb-move'];
    $TANDA_TX = ['pemasukan' => '+', 'pengeluaran' => '−', 'transfer' => ''];
    $WARNA_WALLET = ['#F7BF45', '#9ED9BE', '#C9CDF6', '#F7A27A', '#FFD98A'];

    // persen bar level (sama dengan rumus di komponen gamifikasi)
    $pctLevel = $g['nextPoin'] ? (int) round(($g['poin'] - $g['prevPoin']) / ($g['nextPoin'] - $g['prevPoin']) * 100) : 100;
?>

<?php $__env->startSection('isi'); ?>
<div class="fb">
    <?php if($tagihanTeman > 0): ?>
        <a href="<?php echo e($ke('utang.index')); ?>" class="fc-flash" style="background: #E8F1FF; color: #1E4FA8; border-color: #C7DBFF">
            <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'bell']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'bell']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> Ada <?php echo e($tagihanTeman); ?> tagihan dari teman ForeCash yang belum lunas. Lihat di Utang &amp; Patungan.
        </a>
    <?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal144736fbe443b0bcc386f1346ee0956b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal144736fbe443b0bcc386f1346ee0956b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge-baru','data' => ['uid' => $user->id,'badges' => $g['badges']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge-baru'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['uid' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->id),'badges' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($g['badges'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal144736fbe443b0bcc386f1346ee0956b)): ?>
<?php $attributes = $__attributesOriginal144736fbe443b0bcc386f1346ee0956b; ?>
<?php unset($__attributesOriginal144736fbe443b0bcc386f1346ee0956b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal144736fbe443b0bcc386f1346ee0956b)): ?>
<?php $component = $__componentOriginal144736fbe443b0bcc386f1346ee0956b; ?>
<?php unset($__componentOriginal144736fbe443b0bcc386f1346ee0956b); ?>
<?php endif; ?>

    
    <div class="fb-chips">
        <a href="<?php echo e($ke('pencapaian')); ?>" class="fb-chip fb-chip-level" aria-label="Level <?php echo e($g['level']); ?>, <?php echo e($g['poin']); ?> poin">
            <span class="fb-lv"><?php echo e($g['level']); ?></span>
            <span class="fb-lv-info">
                <span class="fb-lv-row"><span><?php echo e($g['levelNama']); ?></span><small><?php echo e($g['poin']); ?><?php echo e($g['nextPoin'] ? '/' . $g['nextPoin'] : ''); ?> poin</small></span>
                <span class="fb-bar"><span style="width: <?php echo e($pctLevel); ?>%"></span></span>
            </span>
        </a>
        <span class="fb-chip">
            <span class="fb-flame"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'flame','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'flame','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
            <span class="fb-d"><?php echo e($g['streak']); ?> hari</span> beruntun
        </span>
    </div>

    <div class="fb-grid">
        
        <div class="fb-main">
            
            <?php if (isset($component)) { $__componentOriginal2d5983104dbfb38c62518cdf12ae7723 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d5983104dbfb38c62518cdf12ae7723 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero-tupai','data' => ['f' => $f,'mood' => $mood,'jajan' => $jajanHariIni,'batas' => $batasHarian]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-tupai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['f' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($f),'mood' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mood),'jajan' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($jajanHariIni),'batas' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($batasHarian)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d5983104dbfb38c62518cdf12ae7723)): ?>
<?php $attributes = $__attributesOriginal2d5983104dbfb38c62518cdf12ae7723; ?>
<?php unset($__attributesOriginal2d5983104dbfb38c62518cdf12ae7723); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d5983104dbfb38c62518cdf12ae7723)): ?>
<?php $component = $__componentOriginal2d5983104dbfb38c62518cdf12ae7723; ?>
<?php unset($__componentOriginal2d5983104dbfb38c62518cdf12ae7723); ?>
<?php endif; ?>

            
            <section class="fb-stats" aria-label="Ringkasan">
                <div class="fb-stat" style="--c: #F7BF45">
                    <span class="fb-stat-ic"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'wallet','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'wallet','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
                    <p class="fb-stat-label">Total saldo</p>
                    <p class="fb-stat-value"><?php echo e(Format::rupiah($f['saldo'])); ?></p>
                    <p class="fb-stat-sub"><?php echo e($wallets->count()); ?> wallet</p>
                </div>
                <div class="fb-stat" style="--c: #F7A27A">
                    <span class="fb-stat-ic"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'flame','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'flame','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
                    <p class="fb-stat-label">Pengeluaran per hari</p>
                    <p class="fb-stat-value"><?php echo e(Format::rupiah($f['burn'])); ?></p>
                    <p class="fb-stat-sub">rata-rata <?php echo e($f['hari']); ?> hari terakhir</p>
                </div>
                <a href="<?php echo e($ke('utang.index')); ?>" class="fb-stat" style="--c: #9ED9BE">
                    <span class="fb-stat-ic"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'hand-coins','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'hand-coins','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
                    <p class="fb-stat-label">Teman utang ke kamu</p>
                    <p class="fb-stat-value fb-in"><?php echo e(Format::rupiah($piutang)); ?></p>
                    <p class="fb-stat-sub">belum lunas</p>
                </a>
                <a href="<?php echo e($ke('utang.index')); ?>" class="fb-stat" style="--c: #C9CDF6">
                    <span class="fb-stat-ic"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'user-minus','size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'user-minus','size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
                    <p class="fb-stat-label">Kamu utang ke teman</p>
                    <p class="fb-stat-value fb-out"><?php echo e(Format::rupiah($utang)); ?></p>
                    <p class="fb-stat-sub">belum lunas</p>
                </a>
            </section>

            
            <section class="fb-card" aria-label="Transaksi terakhir">
                <div class="fb-head">
                    <h3>Transaksi terakhir</h3>
                    <?php if(Route::has('transaksi.index')): ?><a href="<?php echo e(route('transaksi.index')); ?>" class="fb-link">Lihat semua</a><?php endif; ?>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="fb-tx">
                        <span class="fb-tx-ic <?php echo e($KELAS_TX[$tx->jenis]); ?>"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => Format::kategoriIkon($tx->category?->nama, $tx->jenis),'size' => 20]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Format::kategoriIkon($tx->category?->nama, $tx->jenis)),'size' => 20]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
                        <div class="min-w-0 flex-1">
                            <p class="fb-tx-name"><?php echo e($tx->keterangan); ?></p>
                            <p class="fb-tx-meta">
                                <?php if($tx->jenis === 'transfer'): ?>
                                    <?php echo e($tx->wallet?->nama); ?> ke <?php echo e($tx->walletTujuan?->nama); ?>

                                <?php else: ?>
                                    <?php echo e($tx->category?->nama ?? 'Lainnya'); ?> · <?php echo e($tx->wallet?->nama); ?>

                                <?php endif; ?>
                                · <?php echo e(Format::tgl($tx->tanggal)); ?>

                            </p>
                        </div>
                        <p class="fb-tx-amt <?php echo e($WARNA_TX[$tx->jenis]); ?>"><?php echo e($TANDA_TX[$tx->jenis]); ?><?php echo e(Format::rupiah($tx->nominal)); ?></p>
                        <?php if(Route::has('transaksi.edit')): ?>
                            <a href="<?php echo e(route('transaksi.edit', $tx)); ?>" class="fb-icon-btn" aria-label="Ubah <?php echo e($tx->keterangan); ?>"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'pencil','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'pencil','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php if (isset($component)) { $__componentOriginal2774db502eccf9ab4eb7044e67aef150 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2774db502eccf9ab4eb7044e67aef150 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kosong','data' => ['judul' => 'Belum ada transaksi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kosong'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['judul' => 'Belum ada transaksi']); ?>Mulai dari tombol "Catat transaksi" di atas. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2774db502eccf9ab4eb7044e67aef150)): ?>
<?php $attributes = $__attributesOriginal2774db502eccf9ab4eb7044e67aef150; ?>
<?php unset($__attributesOriginal2774db502eccf9ab4eb7044e67aef150); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2774db502eccf9ab4eb7044e67aef150)): ?>
<?php $component = $__componentOriginal2774db502eccf9ab4eb7044e67aef150; ?>
<?php unset($__componentOriginal2774db502eccf9ab4eb7044e67aef150); ?>
<?php endif; ?>
                <?php endif; ?>
            </section>
        </div>

        
        <aside class="fb-side">
            
            <a href="<?php echo e($ke('pencapaian')); ?>" class="fb-card">
                <div class="fb-head" style="margin-bottom: 8px"><h3>Tantangan minggu ini</h3></div>
                <?php if (isset($component)) { $__componentOriginala5156a08ba1661a5fa8e586a02939437 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala5156a08ba1661a5fa8e586a02939437 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.gamifikasi','data' => ['bagian' => 'tantangan','t' => $g['tantangan']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('gamifikasi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bagian' => 'tantangan','t' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($g['tantangan'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala5156a08ba1661a5fa8e586a02939437)): ?>
<?php $attributes = $__attributesOriginala5156a08ba1661a5fa8e586a02939437; ?>
<?php unset($__attributesOriginala5156a08ba1661a5fa8e586a02939437); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala5156a08ba1661a5fa8e586a02939437)): ?>
<?php $component = $__componentOriginala5156a08ba1661a5fa8e586a02939437; ?>
<?php unset($__componentOriginala5156a08ba1661a5fa8e586a02939437); ?>
<?php endif; ?>
            </a>

            
            <?php if($targetAktif): ?>
                <a href="<?php echo e($ke('rencana.index')); ?>" class="fb-target">
                    <?php if (isset($component)) { $__componentOriginale9273a6e6b83c6abfee85330a8491544 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9273a6e6b83c6abfee85330a8491544 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tupai','data' => ['pose' => 'koin','alt' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tupai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pose' => 'koin','alt' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $attributes = $__attributesOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__attributesOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $component = $__componentOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__componentOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?>
                    <p class="fb-kicker">Target tabungan</p>
                    <h3 class="fb-target-name"><?php echo e($targetAktif->nama); ?></h3>
                    <p class="fb-target-sub"><?php echo e(Format::rupiah($targetAktif->terkumpul)); ?> dari <?php echo e(Format::rupiah($targetAktif->target)); ?></p>
                    <div class="fb-track"><span style="width: <?php echo e($targetAktif->persen()); ?>%"></span></div>
                    <p class="fb-d" style="font-size: 20px"><?php echo e($targetAktif->persen()); ?>%</p>
                </a>
            <?php endif; ?>

            
            <?php if($rencanaDekat): ?>
                <a href="<?php echo e($ke('rencana.index')); ?>" class="fb-card">
                    <p class="fb-kicker" style="color: var(--fb-muted)">Rencana terdekat · <?php echo e(Format::tgl($rencanaDekat->tanggal)); ?></p>
                    <p class="fb-d" style="font-size: 20px; margin-top: 6px"><?php echo e($rencanaDekat->nama); ?></p>
                    <p class="fb-stat-sub"><?php echo e(Format::rupiah($rencanaDekat->nominal)); ?> · <?php echo e($f['rencanaDulu'] > 0 ? 'sudah dihitung di prediksi' : 'jatuh setelah pemasukan berikutnya'); ?></p>
                </a>
            <?php endif; ?>

            
            <section class="fb-card" aria-label="Saldo per wallet">
                <div class="fb-head">
                    <h3>Dompetmu</h3>
                    <?php if(Route::has('wallet.index')): ?><a href="<?php echo e(route('wallet.index')); ?>" class="fb-link">Kelola</a><?php endif; ?>
                </div>
                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="fb-wallet">
                        <span class="fb-tx-ic" style="background: <?php echo e($WARNA_WALLET[$i % 5]); ?>"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => $IKON_WALLET[$w->tipe] ?? 'banknote','size' => 18]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($IKON_WALLET[$w->tipe] ?? 'banknote'),'size' => 18]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
                        <span class="flex-1 min-w-0 font-bold truncate"><?php echo e($w->nama); ?></span>
                        <span class="fb-d"><?php echo e(Format::rupiah($w->saldo_sekarang)); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\audre\ForeCash\resources\views/beranda/index.blade.php ENDPATH**/ ?>