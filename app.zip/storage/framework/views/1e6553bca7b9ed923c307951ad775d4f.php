
<div data-chatbot data-url="<?php echo e(route('chatbot')); ?>" data-nama="<?php echo e(auth()->user()->namaDepan()); ?>" data-ai="<?php echo e(\App\Services\Gemini::aktif() ? 1 : 0); ?>">
    
    <button type="button" id="fcBotBtn" data-bot-tombol aria-label="Buka ForeCash Assistant" title="Tanya ForeCash Assistant (bisa digeser)"
            class="fc-bot-launch fixed z-[90]" style="right: 24px; bottom: 32px">
        <span class="fc-bot-face pointer-events-none"><?php if (isset($component)) { $__componentOriginale9273a6e6b83c6abfee85330a8491544 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9273a6e6b83c6abfee85330a8491544 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tupai','data' => ['pose' => 'senang']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tupai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pose' => 'senang']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $attributes = $__attributesOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__attributesOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $component = $__componentOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__componentOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?></span>
        <span class="fc-bot-text pointer-events-none"><b>Tanya Asisten</b><small>AI keuanganmu</small></span>
        <span class="fc-bot-chat pointer-events-none"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'message-circle','size' => 18,'tebal' => 2.4]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'message-circle','size' => 18,'tebal' => 2.4]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></span>
    </button>

    <div data-bot-panel hidden role="dialog" aria-label="ForeCash Assistant"
         class="fixed z-[91] w-[24rem] max-w-[calc(100vw-1.5rem)] hs-card flex flex-col overflow-hidden" style="height: 32rem">
        <div class="flex items-center gap-3 px-4 py-3 bg-hsYellow">
            <span class="fc-bot-face" style="width: 44px; height: 44px"><?php if (isset($component)) { $__componentOriginale9273a6e6b83c6abfee85330a8491544 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9273a6e6b83c6abfee85330a8491544 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tupai','data' => ['pose' => 'senang']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tupai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pose' => 'senang']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $attributes = $__attributesOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__attributesOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9273a6e6b83c6abfee85330a8491544)): ?>
<?php $component = $__componentOriginale9273a6e6b83c6abfee85330a8491544; ?>
<?php unset($__componentOriginale9273a6e6b83c6abfee85330a8491544); ?>
<?php endif; ?></span>
            <div class="flex-1">
                <p class="font-black text-base flex items-center gap-2">ForeCash Assistant <span class="fc-bot-ai">AI</span></p>
                <p class="text-xs font-semibold text-hsDark/70">Tanya apa saja soal uangmu, aku jawab dari datamu</p>
            </div>
            <button type="button" data-bot-tutup class="w-8 h-8 rounded-full bg-white/70 font-bold inline-flex items-center justify-center" aria-label="Tutup">
                <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'x','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'x','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
            </button>
        </div>
        <div data-bot-list class="flex-1 overflow-y-auto p-4 space-y-3 text-sm" aria-live="polite"></div>
        <div class="flex flex-wrap gap-1.5 px-3 pb-2">
            <?php $__currentLoopData = ['Kapan uangku habis?', 'Tips hemat', 'Cek saldo', 'Utang & piutang', 'Level aku']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bot-saran class="bg-slate-100 hover:bg-hsYellow rounded-full px-3 py-1.5 text-xs font-bold"><?php echo e($s); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <form data-bot-form class="flex gap-2 p-3 border-t">
            <input data-bot-input maxlength="500" placeholder="Tanya soal keuanganmu..." aria-label="Pertanyaan" class="flex-1 min-w-0 px-3 py-2.5 text-sm border rounded-xl" autocomplete="off">
            <button type="submit" class="hs-btn text-white px-4 py-2 text-sm" style="background: #262A3B">Kirim</button>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\audre\ForeCash\resources\views/partials/chatbot.blade.php ENDPATH**/ ?>