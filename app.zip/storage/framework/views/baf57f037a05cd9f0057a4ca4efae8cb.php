<?php use \App\Support\Format; ?>
<?php use \App\Http\Controllers\UtangController; ?>

<?php $__env->startSection('judul', 'Utang & Patungan'); ?>
<?php $__env->startSection('judul_halaman', 'Utang & Patungan'); ?>

<?php $hari = Format::hariIni(); ?>

<?php $__env->startSection('isi'); ?>
    <div><p class="text-xs text-slate-500">Catat utang-piutang antarteman dan bagi tagihan bersama.</p></div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2 space-y-4">
            
            <?php if($pelunasan->isNotEmpty()): ?>
                <section class="hs-card p-5 space-y-1" style="border-color: var(--sun)" aria-label="Pelunasan dari teman">
                    <h4 class="text-sm font-black"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'bell','size' => 15,'class' => 'inline -mt-0.5 text-hsOrange']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'bell','size' => 15,'class' => 'inline -mt-0.5 text-hsOrange']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> Ditandai lunas oleh teman</h4>
                    <?php $__currentLoopData = $pelunasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $masuk = $d->arah === 'piutang'; ?>
                        <div class="py-2 border-b last:border-0 space-y-2">
                            <p class="text-xs">
                                <b><?php echo e($d->nama_teman); ?></b> menandai <b><?php echo e($d->keterangan); ?></b> (<?php echo e(Format::rupiah($d->nominal)); ?>) sudah lunas.
                                <?php echo e($masuk ? 'Uangnya sudah kamu terima?' : 'Sudah kamu bayar?'); ?>

                            </p>
                            <form method="POST" action="<?php echo e(route('utang.pelunasan', $d)); ?>" class="flex gap-2 flex-wrap">
                                <?php echo csrf_field(); ?>
                                <select name="wallet_id" aria-label="<?php echo e($masuk ? 'Masuk ke wallet' : 'Dibayar dari wallet'); ?>" class="flex-1 min-w-[120px] px-2 py-1.5 text-[11px] border">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="hs-btn bg-hsGreen text-white px-3 py-1.5 text-[11px]">Catat <?php echo e($masuk ? 'pemasukan' : 'pengeluaran'); ?></button>
                                <button type="submit" name="abaikan" value="1" class="hs-btn bg-white text-hsDark px-3 py-1.5 text-[11px]" style="border: 2px solid var(--line)">Abaikan</button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            <?php endif; ?>

            
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <?php $__empty_1 = true; $__currentLoopData = $belum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $telat = $d->jatuh_tempo && $d->jatuh_tempo->toDateString() < $hari;
                        $piutang = $d->arah === 'piutang';
                    ?>
                    <div class="hs-card p-5 space-y-3 <?php echo e($telat ? 'border-red-300!' : ''); ?>">
                        <div class="flex justify-between items-start gap-2">
                            <div class="min-w-0">
                                <span class="text-[10px] font-black px-2 py-0.5 rounded-full <?php echo e($piutang ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-700'); ?>">
                                    <?php echo e($piutang ? 'PIUTANG · dia utang ke saya' : 'UTANG · saya utang ke dia'); ?>

                                </span>
                                <p class="font-black mt-2"><?php echo e($d->nama_teman); ?></p>
                                <?php if($d->teman_id): ?>
                                    <p class="text-[10px] font-bold text-hsBlue inline-flex items-center gap-1">
                                        <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'link','size' => 11]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'link','size' => 11]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> <?php echo e($piutang ? 'Tagihan terkirim ke akunnya' : 'Tagihan dari temanmu di ForeCash'); ?>

                                    </p>
                                <?php endif; ?>
                                <p class="text-xs text-slate-500"><?php echo e($d->keterangan); ?></p>
                            </div>
                            <p class="font-black shrink-0"><?php echo e(Format::rupiah($d->nominal)); ?></p>
                        </div>
                        <?php if($d->jatuh_tempo): ?>
                            <p class="text-[11px] font-bold <?php echo e($telat ? 'text-hsRed' : 'text-slate-500'); ?>">
                                Jatuh tempo <?php echo e(Format::tgl($d->jatuh_tempo)); ?><?php echo e($telat ? ' — terlewat' : ''); ?>

                            </p>
                        <?php endif; ?>
                        <div class="flex gap-2 items-center">
                            <form method="POST" action="<?php echo e(route('utang.lunas', $d)); ?>" class="flex gap-2 flex-1">
                                <?php echo csrf_field(); ?>
                                <select name="wallet_id" aria-label="Wallet untuk pelunasan" title="Wallet untuk pelunasan" class="flex-1 min-w-0 px-2 py-1.5 text-[11px] border">
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($w->id); ?>"><?php echo e($w->nama); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="hs-btn bg-hsGreen text-white px-3 py-1.5 text-[11px]">Lunas</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('utang.destroy', $d)); ?>" data-konfirmasi="Hapus catatan ini?">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="w-8 h-8 rounded-full bg-red-50 text-hsRed flex items-center justify-center" title="Hapus" aria-label="Hapus catatan">
                                    <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'trash','size' => 13]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'trash','size' => 13]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
                                </button>
                            </form>
                        </div>
                        <?php if($piutang && ! $d->teman_id): ?>
                            <a href="<?php echo e(UtangController::linkPengingatWA($d->nama_teman, $d->keterangan, (float) $d->nominal)); ?>" target="_blank" rel="noopener"
                               class="text-[11px] font-bold text-hsGreen inline-flex items-center gap-1">
                                <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'message-circle','size' => 13]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'message-circle','size' => 13]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> Kirim pengingat via WhatsApp
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="hs-card p-5 text-xs text-slate-500 sm:col-span-2">Tidak ada utang atau piutang yang belum lunas.</p>
                <?php endif; ?>
            </div>

            <?php if($riwayat->isNotEmpty()): ?>
                <div class="hs-card p-5">
                    <h4 class="text-sm font-black mb-2">Riwayat Lunas</h4>
                    <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="text-xs py-1 border-b last:border-0">
                            <span class="font-bold"><?php echo e($d->nama_teman); ?></span> · <?php echo e($d->keterangan); ?> · <?php echo e(Format::rupiah($d->nominal)); ?> <span class="text-hsGreen font-bold">✓</span>
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="space-y-6">
            
            <section class="hs-card p-5 space-y-3" aria-label="Teman ForeCash">
                <h4 class="text-sm font-black"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'user-plus','size' => 15,'class' => 'inline -mt-0.5 text-hsBlue']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'user-plus','size' => 15,'class' => 'inline -mt-0.5 text-hsBlue']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> Teman ForeCash</h4>
                <p class="text-[11px] text-slate-500">Berteman di ForeCash supaya tagihan split bill langsung masuk ke akun temanmu, dan status lunasnya otomatis sama di kedua akun.</p>
                <div class="flex items-center gap-2 rounded-2xl bg-sky-50 px-3 py-2">
                    <div class="flex-1">
                        <p class="text-[10px] font-bold text-slate-500">Kode temanmu</p>
                        <p class="font-black text-lg tracking-[.2em]"><?php echo e($user->kode_teman ?? '-'); ?></p>
                    </div>
                    <?php if($user->kode_teman): ?>
                        <button type="button" data-salin="<?php echo e($user->kode_teman); ?>" class="hs-btn bg-white text-hsDark px-3 py-2 text-xs inline-flex items-center gap-1" style="border: 2px solid var(--line)">
                            <?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'copy','size' => 14]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'copy','size' => 14]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> <span>Salin</span>
                        </button>
                    <?php endif; ?>
                </div>
                <form method="POST" action="<?php echo e(route('teman.store')); ?>" class="flex gap-2">
                    <?php echo csrf_field(); ?>
                    <input name="kode" required maxlength="8" placeholder="Kode teman, mis. ANDI26" aria-label="Kode teman" autocomplete="off"
                           class="flex-1 min-w-0 px-3 py-2 text-xs border uppercase">
                    <button type="submit" class="hs-btn bg-hsBlue text-white px-4 py-2 text-xs">Tambah</button>
                </form>
                <?php if($errors->teman->any()): ?>
                    <p class="text-xs font-bold text-hsRed"><?php echo e($errors->teman->first()); ?></p>
                <?php endif; ?>
                <?php if($teman->isNotEmpty()): ?>
                    <ul class="space-y-1">
                        <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-center gap-2 py-1">
                                <span class="fc-chip-av" style="width: 34px; height: 34px"><?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['id' => $t->avatar,'size' => 32]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($t->avatar),'size' => 32]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?></span>
                                <span class="flex-1 text-sm font-bold truncate"><?php echo e($t->name); ?></span>
                                <form method="POST" action="<?php echo e(route('teman.destroy', $t)); ?>" data-konfirmasi="Putus pertemanan dengan <?php echo e($t->name); ?>?">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="w-8 h-8 rounded-full bg-red-50 text-hsRed inline-flex items-center justify-center"
                                            aria-label="Putus pertemanan dengan <?php echo e($t->name); ?>" title="Putus pertemanan"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'user-minus','size' => 14]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'user-minus','size' => 14]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?></button>
                                </form>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </section>

            
            <form method="POST" action="<?php echo e(route('utang.split')); ?>" id="split" class="hs-card p-5 space-y-3" data-split>
                <?php echo csrf_field(); ?>
                <h4 class="text-sm font-black"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'calculator','size' => 15,'class' => 'inline -mt-0.5 text-hsPurple']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'calculator','size' => 15,'class' => 'inline -mt-0.5 text-hsPurple']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> Split Bill</h4>
                <?php if($errors->split->any()): ?>
                    <p class="text-xs font-bold text-hsRed"><?php echo e($errors->split->first()); ?></p>
                <?php endif; ?>
                <div>
                    <label for="sj" class="text-xs font-bold">Judul</label>
                    <input id="sj" name="judul" maxlength="150" value="<?php echo e(old('judul')); ?>" placeholder="Makan malam angkatan" class="w-full px-3 py-2 text-xs border">
                </div>
                <div>
                    <label for="st" class="text-xs font-bold">Total tagihan (Rp)</label>
                    <input id="st" name="total" required type="text" inputmode="numeric" autocomplete="off" value="<?php echo e(old('total')); ?>"
                           placeholder="Contoh: 150.000" class="w-full px-3 py-2 text-xs border" data-rupiah>
                </div>
                <?php if($teman->isNotEmpty()): ?>
                    <fieldset class="space-y-1.5">
                        <legend class="text-xs font-bold">Teman ForeCash (tagihan langsung masuk ke akunnya)</legend>
                        <div class="flex flex-wrap gap-2">
                            <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="fc-chip-teman">
                                    <input type="checkbox" name="teman_fc[]" value="<?php echo e($t->id); ?>" class="sr-only" <?php if(in_array($t->id, old('teman_fc', []))): echo 'checked'; endif; ?>>
                                    <span class="fc-chip-av"><?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['id' => $t->avatar,'size' => 26]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($t->avatar),'size' => 26]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?></span>
                                    <?php echo e(\Illuminate\Support\Str::before($t->name, ' ') ?: $t->name); ?>

                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </fieldset>
                <?php endif; ?>
                <div>
                    <label for="sn" class="text-xs font-bold"><?php echo e($teman->isNotEmpty() ? 'Teman lain (pisahkan dengan koma)' : 'Nama teman (pisahkan dengan koma)'); ?></label>
                    <input id="sn" name="teman" value="<?php echo e(old('teman')); ?>" placeholder="Budi, Siti, Bima" class="w-full px-3 py-2 text-xs border">
                </div>
                <label class="flex items-center gap-2 text-xs font-bold">
                    <input type="checkbox" name="termasuk_saya" value="1" <?php if(old('termasuk_saya', '1')): echo 'checked'; endif; ?>> Saya ikut menanggung bagian
                </label>
                <p class="text-xs font-bold text-hsPurple" data-split-hasil hidden></p>
                <div>
                    <label for="sd" class="text-xs font-bold">Jatuh tempo (opsional)</label>
                    <input id="sd" type="date" name="jatuh_tempo" value="<?php echo e(old('jatuh_tempo')); ?>" class="w-full px-3 py-2 text-xs border">
                </div>
                <button type="submit" class="hs-btn bg-hsPurple text-white w-full py-2.5 text-xs">Bagi &amp; Catat Piutang</button>
            </form>

            
            <form method="POST" action="<?php echo e(route('utang.store')); ?>" class="hs-card p-5 space-y-3" data-catat-utang>
                <?php echo csrf_field(); ?>
                <h4 class="text-sm font-black"><?php if (isset($component)) { $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ikon','data' => ['nama' => 'plus','size' => 15,'class' => 'inline -mt-0.5 text-hsGreen']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nama' => 'plus','size' => 15,'class' => 'inline -mt-0.5 text-hsGreen']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $attributes = $__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__attributesOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09)): ?>
<?php $component = $__componentOriginal8d917d15c7538e1421c51d0f23f3fc09; ?>
<?php unset($__componentOriginal8d917d15c7538e1421c51d0f23f3fc09); ?>
<?php endif; ?> Catat Utang / Piutang</h4>
                <?php if($errors->catat->any()): ?>
                    <p class="text-xs font-bold text-hsRed"><?php echo e($errors->catat->first()); ?></p>
                <?php endif; ?>
                <?php if($teman->isNotEmpty()): ?>
                    <div>
                        <label for="dfc" class="text-xs font-bold">Teman ForeCash (opsional)</label>
                        <select id="dfc" name="teman_fc" class="w-full px-3 py-2 text-xs border" data-pilih-teman>
                            <option value="">Bukan pengguna ForeCash</option>
                            <?php $__currentLoopData = $teman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($t->id); ?>" <?php if((string) old('teman_fc') === (string) $t->id): echo 'selected'; endif; ?>><?php echo e($t->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                <?php endif; ?>
                <div data-nama-teman>
                    <label for="dn" class="text-xs font-bold">Nama teman</label>
                    <input id="dn" name="nama_teman" maxlength="100" value="<?php echo e(old('nama_teman')); ?>" class="w-full px-3 py-2 text-xs border">
                </div>
                <div>
                    <label for="dk" class="text-xs font-bold">Keterangan</label>
                    <input id="dk" name="keterangan" required maxlength="150" value="<?php echo e(old('keterangan')); ?>" placeholder="Pinjam untuk ongkos" class="w-full px-3 py-2 text-xs border">
                </div>
                <div>
                    <label for="dnom" class="text-xs font-bold">Nominal (Rp)</label>
                    <input id="dnom" name="nominal" required type="text" inputmode="numeric" autocomplete="off" value="<?php echo e(old('nominal')); ?>"
                           placeholder="Contoh: 20.000" class="w-full px-3 py-2 text-xs border" data-rupiah>
                </div>
                <div>
                    <label for="da" class="text-xs font-bold">Posisi</label>
                    <select id="da" name="arah" class="w-full px-3 py-2 text-xs border">
                        <option value="piutang" <?php if(old('arah') === 'piutang'): echo 'selected'; endif; ?>>Dia utang ke saya (piutang)</option>
                        <option value="utang" <?php if(old('arah') === 'utang'): echo 'selected'; endif; ?> data-bukan-teman>Saya utang ke dia (utang)</option>
                    </select>
                    <p class="text-[10px] text-slate-500 mt-1" data-info-teman hidden>Tagihan akan muncul di akun temanmu.</p>
                </div>
                <div>
                    <label for="dt" class="text-xs font-bold">Jatuh tempo (opsional)</label>
                    <input id="dt" type="date" name="jatuh_tempo" value="<?php echo e(old('jatuh_tempo')); ?>" class="w-full px-3 py-2 text-xs border">
                </div>
                <button type="submit" class="hs-btn bg-hsGreen text-white w-full py-2.5 text-xs">Simpan</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\audre\ForeCash\resources\views/utang/index.blade.php ENDPATH**/ ?>