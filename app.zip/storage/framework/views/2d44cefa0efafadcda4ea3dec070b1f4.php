
<?php if(session('sukses')): ?>
    <p class="fc-flash" role="status"><?php echo e(session('sukses')); ?></p>
<?php endif; ?>
<?php if(session('error')): ?>
    <p class="fc-flash is-error" role="alert"><?php echo e(session('error')); ?></p>
<?php endif; ?>
<?php /**PATH C:\Users\audre\ForeCash\resources\views/partials/flash.blade.php ENDPATH**/ ?>